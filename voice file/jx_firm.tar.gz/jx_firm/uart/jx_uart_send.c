#include "jx_uart_send.h"

// UART1_RX串口通信消息头
const unsigned char g_uart_send_head_UART1_RX[] = {
  0xaa, 0x55
};

// UART1_RX串口通信消息尾
const unsigned char g_uart_send_foot_UART1_RX[] = {
  0x55, 0xaa
};

// 串口发送函数实现
void _uart_send_impl(int port, unsigned char* buff, int len) {
  // TODO: 调用项目实际的串口发送函数
  /*
  int i = 0;
  unsigned char c;
  for (i = 0; i < len; i++) {
    c = buff[i];
    printf("%02X ", c);
  }
  printf("\n");
  */
}

// action: bark1
void _uart_bark1(unsigned char barkType) {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART1_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART1_RX[i];
  }
  buff[2] = U_MSG_bark1;
  param.d_uchar = barkType;
  buff[3] = param.d_uchar;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART1_RX; i++) {
      buff[i + 4] = g_uart_send_foot_UART1_RX[i];
  }
  _uart_send_impl(1, buff, 6);
}

// action: number_read
void _uart_number_read(char number_call) {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART1_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART1_RX[i];
  }
  buff[2] = U_MSG_number_read;
  param.d_char = number_call;
  buff[3] = param.d_uchar;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART1_RX; i++) {
      buff[i + 4] = g_uart_send_foot_UART1_RX[i];
  }
  _uart_send_impl(1, buff, 6);
}

