from machine import Pin, ADC
from board import *

__version__ = "1.0.0"

def get_gas_sensor_data(type,pin):
    ports = {
        "P1": PORT1,
        "P2": PORT2,
        "P3": PORT3,
        "P4": PORT4
    }
    gas_pin = ADC(Pin(ports[pin]))
    gas_pin.atten(ADC.ATTN_11DB)
    return gas_pin.read()