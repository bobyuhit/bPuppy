from machine import Pin
from future import PINMAP

__version__ = "1.0.0"

class SugarAtomizer(Pin):
    def __init__(self,pin):
        super().__init__(PINMAP[pin],Pin.OUT)