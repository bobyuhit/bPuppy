from machine import UART
from future import *
from time import *
import socket
import errno
import ubinascii
import _thread

__version__ = "1.0.12"
VERSIONS = 'K0'
QRCODE = 'K11'
RECOGNIZE = "K12"
PLAYAUDIO = "K15"
ISDARKNESS = "K17"
AUDIOTEST = "K18"
BUTTONSTATE = "K19"
MQQTTCONNECT = "K20"
MQTTSUBSCRIPTION = "K21"
MQTTMESSAGE = "K22"
MQTTSEND = "K23"
SETGRB = "K16"
SETALLRGB = "K25"
OCR = "K28"
IPADDR = "K4"


class SugarCam:
    def __init__(self, tx='P2', rx='P12', id=1):
        self.uart = UART(id, 115200, tx=PINMAP[tx], rx=PINMAP[rx])

        self.uart.write(bytes('\n\n', 'utf-8'))
        sleep(0.4)
        flag = ''
        count = 0
        while True:
            if count == 10:
                print("Please try to reset the sugar_cam!!")
                count = 0
            data = self.uart.readline()
            print(data)
            if data:
                try:
                    flag = str(data, 'UTF-8')
                    if VERSIONS in flag:
                        pass
                        break
                    else:
                        pass
                except:
                    pass
                    flag = ''
            else:
                self.uart.write('{} \r\n'.format(VERSIONS).encode())
                count += 1
                sleep(1)

    def getQRcode(self):
        data = None
        self.uart.read()
        self.uart.write('{} \r\n'.format(QRCODE).encode())
        sleep(2)
        data = self.uart.read()
        if data:
            try:
                data = data.decode().split(" ")
                if data[0] != QRCODE:
                    return None
                else:
                    if data[1][0:4] == 'None':
                        return None
                    else:
                        data = data[1].replace("\n", "").replace(
                            "\r", "").lstrip().rstrip()
                        return data
            except:
                return None
            
    def ocr(self,timeout=5000):
        data = None
        self.uart.read()
        self.uart.write('{} \r\n'.format(OCR).encode())
        startTime = ticks_ms()
        while True:
            if ticks_ms() - startTime > timeout:
                return 0
            data = self.uart.readline()
            if data:
                try:
                    data = data.decode().strip().split(" ")
                    if data[0] == OCR:
                        result = ""
                        index=1
                        while True:
                            result += data[index]
                            index+=1
                            if index == len(data):
                                break
                            else:
                                result+=","
                        
                        return result
                except:
                    return 0

    def ipAddr(self,timeout=5000):
        data = None
        self.uart.read()
        self.uart.write('{} \r\n'.format(IPADDR).encode())
        startTime = ticks_ms()
        while True:
            if ticks_ms() - startTime > timeout:
                return 0
            data = self.uart.readline()
            if data:
                try:
                    data = data.decode().strip().split(" ")
                    if data[0] == IPADDR:
                        return data[1]
                except:
                    return 0
            
    def isDarkness(self):
        data = None
        self.uart.read()
        self.uart.write('{} \r\n'.format(ISDARKNESS).encode())
        sleep(0.5)
        data = self.uart.read()
        if data:
            try:
                data = data.decode().split(" ")
                print(data)
                if data[0] != ISDARKNESS:
                    return None
                elif "False" in str(data[1]):
                    return False
                elif "True" in str(data[1]):
                    return True
            except:
                return False

    def playAudio(self, wav):
        self.uart.write('{} {} \r\n'.format(PLAYAUDIO, wav).encode())
        sleep(1)

    def audioTest(self):
        self.uart.write('{} \r\n'.format(AUDIOTEST).encode())
        sleep(1)

    def setColor(self, color1, color2):
        self.uart.write('{} {} {} \r\n'.format(SETGRB, str(color1).replace(
            ' ', ''), str(color2).replace(' ', '')).encode())
        sleep(1)

    def setAllColor(self, color1):
        self.uart.write('{} {} \r\n'.format(
            SETALLRGB, str(color1).replace(' ', '')).encode())
        sleep(1)

    def recognize(self, sec):
        data = None
        data = self.uart.read()
        self.uart.write('{} {} \r\n'.format(RECOGNIZE, sec).encode())
        num = 0
        while num != 12:
            sleep(1)
            data = self.uart.read()
            if data:
                try:
                    data = data.decode().split(",")
                    if data[0] != RECOGNIZE:
                        return None
                    else:
                        if data[1][0:4] == 'None':
                            return None
                        else:
                            data = data[1]
                            if data[-2:] == "\r\n":
                                data = data[:-2]
                            print(len(data))
                            return data
                except:
                    return None
            num += 1

    def buttonState(self, button):
        btnMap = {
            "BTNA":"1",
            "BTNB":"2",
        }
        data = None
        data = self.uart.readline()
        if data:
            try:
                data = data.decode().strip().split(" ")
                if data[0] != BUTTONSTATE:
                    return False
                else:
                    if len(data) != 2:
                        return False
                    if data[1] != btnMap[button]:
                        return False
                    return True
            except:
                return False
        else:
            return False


class FPV:
    def __init__(self, ip, secret):
        self.ip = ip
        self.secret = secret
        self.status = False
        self.t0 = ticks_ms()
        self.startMonitor()

    def decodeCmd(self, data):
        cmds = data.split(' ')
        if len(cmds) < 2:
            return
        if cmds[0] == "K1":
            buff = ubinascii.a2b_base64(cmds[1])
            screen.loadJpgBuff(buff)

    def startMonitor(self, port=9233):
        ip = self.ip
        secret = self.secret
        self.cmd = "K1 %s \r\n" % secret
        self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.s.bind(socket.getaddrinfo("0.0.0.0", 17758)[0][-1])
        self.addr = socket.getaddrinfo(ip, port)[0][-1]
        self.s.setblocking(False)
        # s.settimeout(1)

    def refreshCam(self):
        try:
            if ticks_ms() - self.t0 > 5000:
                res = self.s.sendto(self.cmd, self.addr)
        except OSError as e:
            if e.args[0] == 118:
                _sync = screen.sync
                screen.sync = 1
                screen.clear()
                screen.showmsg(translate('Connect wifi first'),
                               translate("Camera connect fail"), type='err')
                screen.sync = _sync
                print("Please connect wifi first")
            # 处理其他类型的 OSError 异常
            else:
                print(e)
        data = b""
        try:
            count = 0
            while True:
                count+=1
                if count==10:
                    print("Retry multiple")
                    break
                rx, addr = self.s.recvfrom(16*1024)
                #print("rx", len(data), addr)
                if rx:
                    data += rx
                    _tmp = data.split(b'\n')
                    if len(_tmp) > 1:
                        data = _tmp[-1]
                        try:
                            self.decodeCmd(_tmp[0].decode('utf-8'))
                            break
                        except:
                            pass
        except OSError as err:
            if err.args[0] != errno.EAGAIN and err.args[0] != errno.EWOULDBLOCK:
                raise
            else:
                sleep_ms(100)
