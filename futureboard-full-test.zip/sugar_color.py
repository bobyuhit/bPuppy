import time
from future import i2c
import math

__version__ = "1.0.3"

# I2C address of the device
BH1745NUC_DEFAULT_ADDRESS				= 0x38

# BH1745NUC Register Set
BH1745NUC_REG_SYSTEM					= 0x40 # System Control Register
BH1745NUC_REG_MODE_CONTROL1				= 0x41 # Mode Control 1 Register
BH1745NUC_REG_MODE_CONTROL2				= 0x42 # Mode Control 2 Register
BH1745NUC_REG_MODE_CONTROL3				= 0x44 # Mode Control 3 Register
BH1745NUC_REG_RED_DATA_LSB				= 0x50 # Red low data register
BH1745NUC_REG_RED_DATA_MSB				= 0x51 # Red high data register
BH1745NUC_REG_GREEN_DATA_LSB			= 0x52 # Green low data register
BH1745NUC_REG_GREEN_DATA_MSB			= 0x53 # Green high data register
BH1745NUC_REG_BLUE_DATA_LSB				= 0x54 # Blue low data register
BH1745NUC_REG_BLUE_DATA_MSB				= 0x55 # Blue high data register
BH1745NUC_REG_CLEAR_DATA_LSB			= 0x56 # Clear low data register
BH1745NUC_REG_CLEAR_DATA_MSB			= 0x57 # Clear high data register

# BH1745NUC Mode Control-1 Register Configuration
BH1745NUC_RGBC_MEASURE_TIME_160			= 0x00 # RGBC Measurement time = 160 ms
BH1745NUC_RGBC_MEASURE_TIME_320			= 0x01 # RGBC Measurement time = 320 ms
BH1745NUC_RGBC_MEASURE_TIME_640			= 0x02 # RGBC Measurement time = 640 ms
BH1745NUC_RGBC_MEASURE_TIME_1280		= 0x03 # RGBC Measurement time = 1280 ms
BH1745NUC_RGBC_MEASURE_TIME_2560		= 0x04 # RGBC Measurement time = 2560 ms
BH1745NUC_RGBC_MEASURE_TIME_5120		= 0x05 # RGBC Measurement time = 5120 ms

# BH1745NUC Mode Control-2 Register Configuration
BH1745NUC_VALID_NO_UPDATE				= 0x00 # RGBC data is not updated after last writing MODE_CONTROL-1,2,3 register or last reading MODE_CONTROL2 register
BH1745NUC_VALID_UPDATE					= 0x80 # RGBC data is updated after last writing MODE_CONTROL-1,2,3 register or last reading MODE_CONTROL2 register
BH1745NUC_RGBC_DS						= 0x00 # RGBC measurement is inactive and becomes power down
BH1745NUC_RGBC_EN						= 0x10 # RGBC measurement is active
BH1745NUC_ADC_GAIN_1					= 0x00 # Gain = 1x
BH1745NUC_ADC_GAIN_2					= 0x01 # Gain = 2x
BH1745NUC_ADC_GAIN_16					= 0x02 # Gain = 16x

# BH1745NUC Mode Control-3 Register Configuration
BH1745NUC_DEFAULT_RESERVED				= 0x02 # Default value

def rgb_to_hsv(rgb):
	r, g, b = rgb
	maxc = max(r, g, b)
	minc = min(r, g, b)
	v = maxc
	if minc == maxc:
		return 0.0, 0.0, v
	s = (maxc-minc) / maxc
	rc = (maxc-r) / (maxc-minc)
	gc = (maxc-g) / (maxc-minc)
	bc = (maxc-b) / (maxc-minc)
	if r == maxc:
		h = bc-gc
	elif g == maxc:
		h = 2.0+rc-bc
	else:
		h = 4.0+gc-rc
	h = (h/6.0) % 1.0
	return h, s, v

def rgb_to_hue(rgb):
	r, g, b = rgb
	h, _, _ = rgb_to_hsv((r/255.0, g/255.0, b/255.0))
	hue_angle = h * 360
	return math.floor(hue_angle)

class SugarColor():
	def __init__(self):
		self.bus = i2c
		self.red = 0
		self.green = 0
		self.blue = 0
		self.lm = 0
		self.time_config()
		self.gain_config()
		self.write_default()
		self.hue = 0
	
	def time_config(self):
		"""Select the mode control-1 register configuration from the given provided values"""
		TIME_CONFIG = (BH1745NUC_RGBC_MEASURE_TIME_160)
		self.bus.writeto_mem(BH1745NUC_DEFAULT_ADDRESS, BH1745NUC_REG_MODE_CONTROL1, bytearray([TIME_CONFIG]))
	
	def gain_config(self):
		"""Select the mode control-2 register configuration from the given provided values"""
		GAIN_CONFIG = (BH1745NUC_VALID_UPDATE | BH1745NUC_RGBC_EN | BH1745NUC_ADC_GAIN_1)
		self.bus.writeto_mem(BH1745NUC_DEFAULT_ADDRESS, BH1745NUC_REG_MODE_CONTROL2, bytearray([GAIN_CONFIG]))
	
	def write_default(self):
		"""Select the mode control-2 register configuration from the given provided values"""
		self.bus.writeto_mem(BH1745NUC_DEFAULT_ADDRESS, BH1745NUC_REG_MODE_CONTROL3, bytearray([BH1745NUC_DEFAULT_RESERVED]))
	
	def update(self):
		"""Read data back from BH1745NUC_REG_RED_DATA_LSB(0x50), 8 bytes
		Red LSB, Red MSB, Green LSB, Green MSB, Blue LSB, Blue MSB, cData LSB, cData MSB"""
		data = self.bus.readfrom_mem(BH1745NUC_DEFAULT_ADDRESS, BH1745NUC_REG_RED_DATA_LSB, 8)
		
		# Convert the data
		self.red = data[1] * 256 + data[0]
		self.green = data[3] * 256 + data[2]
		self.blue = data[5] * 256 + data[4]
		self.lm = data[7] * 256 + data[6]

		self.green=self.green-75

		maxVal = self.red
		if self.green > maxVal:
			maxVal = self.green
		if self.blue > maxVal:
			maxVal = self.blue
		maxVal=maxVal+50 #

		
		self.red = int(self.red/maxVal*255)
		self.green = int(self.green/maxVal*255)
		self.blue = int((self.blue-40)/maxVal*255)

		if self.red < 0:
			self.red = 0
		if self.red >255:
			self.red = 255

		if self.green < 0:
			self.green = 0
		if self.green >255:
			self.green = 255

		if self.blue < 0:
			self.blue = 0
		if self.blue >255:
			self.blue = 255

		self.hue = rgb_to_hue((self.red,self.green,self.blue))


if __name__=='__main__':
	color = SugarColor()
	screen.sync = 0
	neopix=NeoPixel('P7',3)
	while True:
		color.update()
		screen.fill(((color.red, color.green, color.blue)))
		screen.refresh()
		neopix.setColorAll(((color.red, color.green, color.blue)))
		neopix.update()
		print((color.red, color.green, color.blue))
