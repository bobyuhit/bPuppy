import struct
from future import *

__version__ = "1.0.0"

class Solar:
    ADDR = 37
    def __init__(self):
        self.i2c = i2c
        screen.sync = 0

        # 等待直到设备连接到I2C接口
        connected = False
        while not connected:
            try:
                if self.ADDR in self.i2c.scan():
                    connected = True
                else:
                    # print(self.i2c.scan())
                    screen.fill((0, 0, 0))
                    screen.rect(0,0,160,20,(255, 0, 0),1)
                    screen.text('Solar module not found!',5,5,1,(255, 255, 255))
                    screen.text('Please connect module',5,30,1,(255, 255, 255))
                    screen.text('to the I2C interface',5,50,1,(255, 255, 255))
                    screen.refresh()
                    sleep(0.5)  

                    screen.fill((0, 0, 0))
                    screen.rect(0,0,160,20,(0, 255, 0),1)
                    screen.text('Solar module not found!',5,5,1,(255, 255, 255))
                    screen.text('Please connect module',5,30,1,(255, 255, 255))
                    screen.text('to the I2C interface',5,50,1,(255, 255, 255))
                    screen.refresh()
                    sleep(0.5)  
            except Exception as e:
                pass
        
    def reg_write(self, reg, buff):
        buf = bytearray([reg])
        if isinstance(buff, int):
            buf.append(buff)
        else:
            buf.extend(buff)
        self.i2c.writeto(self.ADDR, buf)

    def reg_read(self, reg, n=1):
        self.i2c.writeto(self.ADDR, bytes([reg]))
        out = bytearray(n)
        self.i2c.readfrom_into(self.ADDR, out)
        if len(out) == 1:
            return out[0]
        return out

    def version(self):
        return self.reg_read(0x00, 1)
    

    def battery_level(self):
        buf = self.reg_read(0x02, 4)
        bat = struct.unpack('f', buf)
        return bat[0]
    
    def set_power(self, val):
        self.reg_write(0x03, val)

    def set_rtc(self, yy, mm, dd, hh, mn, ss):
        if yy > 2000:
            yy -= 2000
        self.reg_write(0x05, bytearray([yy, mm, dd, hh, mn, ss]))

    def read_rtc(self):
        [yy, mm, dd, hh, mn, ss] = self.reg_read(0x06, 6)
        yy += 2000
        return (yy, mm, dd, hh, mn, ss)
    
    def set_alarm(self, hh, mm, ss, down=0):
        self.reg_write(0x04, bytearray([hh, mm, ss, down]))
