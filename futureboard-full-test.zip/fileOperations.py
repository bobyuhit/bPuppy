import os

__version__ = "1.0.0"

def write_file(filename, data):
    with open(filename, 'w') as f:
        f.write(data)

def append_to_file(filename, data):
    with open(filename, 'a') as f:
        f.write(data)

def read_file_lines(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    return lines

def read_file(filename):
    with open(filename, 'r') as f:
        data = f.read()
    return data

def remove_file(filename):
    os.remove(filename)