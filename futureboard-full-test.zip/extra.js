{
  rgb2hex: (args) => {
    var R = args.R
    var G = args.G
    var B = args.B
    return "#" + (1 << 24 | R << 16 | G << 8 | B).toString(16).slice(1)
  },
    argsHook: {
    STRING_TXT: (txt, args, block) => {
      if (!args.gen) {
        if (!Number.isNaN(Number(txt))) {
          return `"${txt}"`
        } else if ((txt.startsWith('"') && txt.endsWith('"')) || (txt.startsWith("'") && txt.endsWith("'"))) {
          return `${txt}`
        } else {
          return `"${txt}"`
        }
      } else {
        if (!Number.isNaN(Number(txt))) {
          return `"${txt}"`
        } else if (txt.startsWith('(') && txt.endsWith(')')) {
          return txt.substring(1, txt.length - 1);
        } else if ((txt.startsWith('"') && txt.endsWith('"')) || (txt.startsWith("'") && txt.endsWith("'"))) {
          return txt
        } else {
          return `"${txt}"`
        }
      }
    }
  }
}