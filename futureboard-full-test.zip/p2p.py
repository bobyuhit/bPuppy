import network
from esp import espnow
from time import sleep_ms


class P2pCtrl:

  def __init__(self,channe = 3,cb=None):
    self.w0 = network.WLAN(network.STA_IF)
    self.w0.active(True)
    self.mac = self.w0.config('mac')
    self.target_mac = None
    self.e = espnow.ESPNow()
    self.e.init()
    self.onRecv = cb
    self.e.on_recv(self._on_recv)
    self.rxcache = {}
    self.channel = channe
    sleep_ms(500)
    while True:
        data = self.read()
        if data:
            print(data)
            if data["msg"] == self.mac:
                self.target_mac = data["mac"]
                self.add(self.target_mac)
                self.send(self.target_mac)
                break
            sleep_ms(500)
    print("配对完成，设备mac：",data["mac"])

  def __del__(self):
    self.e.deinit()

  @property
  def channel(self):
    return self.e.channel()

  @channel.setter
  def channel(self, channel):
    self.e.channel(channel)

  def add(self, addr):
    try:
      self.e.add_peer(addr)
    except:
      pass

  def _on_recv(self, mac, msg):
    if self.onRecv:
      self.onRecv(msg, mac)
    else:
      self.rxcache["mac"] = mac
      self.rxcache["msg"] = msg

  def send(self, msg):
    self.e.send(self.target_mac, msg)
    sleep_ms(10)

  def read(self):
    try:
      data = self.rxcache
      if data:
        self.rxcache = {}
      return data
    except:
      return None

  def readBytes(self):
    try:
      data = self.rxcache
      if data:
        self.rxcache = {}
      return data
    except:
      return None