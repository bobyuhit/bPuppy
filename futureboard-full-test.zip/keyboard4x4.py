from time import sleep
from machine import Pin


__version__ = "1.0.0"


class Keypad:

    def __init__(self, scl, sdo, inputs=16):
        self.map = {
            3: "1", 15: "2", 4: "3", 8: "A", 2: "4", 14: "5", 5: "6", 9: "B", 1: "7", 13: "8", 6: "9", 10: "C", 0: "*", 12: "0", 7: "#", 11: "D", -1: None
        }
        self._scl_pin = Pin(PINMAP[scl],Pin.OUT)
        self._sdo_pin = Pin(PINMAP[sdo],Pin.IN)

        self._inputs = inputs

    def read(self):
        key = [1] * self._inputs
        self._scl_pin.value(1)
        sleep(0.001)
        for i in range(self._inputs):
            self._scl_pin.value(0)
            sleep(0.001)
            key[i] = self._sdo_pin.value()
            self._scl_pin.value(1)
            sleep(0.001)
        sleep(0.001)
        key_single = -1
        for i in range(self._inputs):
            if key[i] == 0:
                key_single = i
                break

        return self.map[key_single]
k = Keypad("P2","P12")