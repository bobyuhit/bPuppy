from time import *
import urequests
import ujson
from l10n import translate
from future import screen

__version__ = "1.1.2"

class Amap():
    def __init__(self):
        self._key = None
        self._lives = None
        self._forecast = None
        self.reErrMsg = {  
            '10001': 'Invalid user key',  # key不正确或过期
            '10003': 'Daily query over limit',  # 访问已超出日访问量
            '10004': 'Access too frequent',    # 1分钟内访问过于频繁
        }

    def setAppKey(self,key):
        self._key = key

    # 实况天气每小时更新多次
    def getWeatherLives(self,city):
        if type(city) == list:
            city = bytearray(city).decode()
        r = urequests.get('https://restapi.amap.com/v3/weather/weatherInfo?city={0}&extensions=base&key={1}'.format(city,self._key))

        if r.status_code == 200:
            self._lives = ujson.loads(r.content)
            if not(self._lives['infocode'] == '10000'):
                if self._lives['infocode'] in self.reErrMsg:
                    # raise Exception(translate(self.reErrMsg[self._lives['infocode']]))
                    print(translate(self.reErrMsg[self._lives['infocode']]))
                else:
                    print(translate('Requested Error'))
                    # raise Exception(translate('Requested Error'))
        else:
            # raise Exception(translate('Requested Error'))
            print(translate('Requested Error'))

    def weatherLives(self, type):
        if (self._lives):
            return self._lives['lives'][0][type]
        else:
            return ''

    # 预报天气每天更新3次，分别在8、11、18点左右更新。
    def getWeatherForecast(self,city):
        if type(city) == list:
            city = bytearray(city).decode()
        r = urequests.get('https://restapi.amap.com/v3/weather/weatherInfo?city={0}&extensions=all&key={1}'.format(city,self._key))
        
        if r.status_code == 200:
            self._forecast = ujson.loads(r.content)
            if not(self._forecast['infocode'] == '10000'):
                if self._forecast['infocode'] in self.reErrMsg:
                    raise Exception(translate(self.reErrMsg[self._forecast['infocode']]))    
                else:
                    raise Exception(translate('Requested Error'))  
        else:
            raise Exception(translate('Requested Error'))

    def weatherForecast(self,day,type):
        if (self._lives):
            return self._forecast['forecasts'][0]['casts'][day][type]
        else:
            return ''
    
    def togcj(self,location_gps,coordsys):
        location_gps = str(location_gps)
        r = urequests.get("https://restapi.amap.com/v3/assistant/coordinate/convert?locations={0}&coordsys={1}&output=json&key={2}".format(location_gps,coordsys,self._key))
        if r.status_code == 200:
            location_gcj20 = r.json()["locations"]
            return location_gcj20
        else:
            return None

    def displayStaticMap(self,location_gcj20,zoom):
        r = urequests.get("https://restapi.amap.com/v3/staticmap?location={0}&zoom={1}&size=160*128&markers=mid,,K:{2}&key={3}".format(location_gcj20,zoom,location_gcj20,self._key))
        if r.status_code == 200:
            with open("map.png",'wb') as f:
                f.write(r.content)
            screen.loadPng("map.png")

    def searchLocation(self,place):
        r = urequests.get("https://restapi.amap.com/v3/geocode/geo?address={0}&output=json&key={1}".format(place,self._key))
        if r.status_code == 200:
          try:
            location_gcj20 = r.json()["geocodes"][0]["location"]
            return location_gcj20
          except:
            return "0,0"
          
    def distanceCalculation(self,coord1,coord2):
        r = urequests.get("https://restapi.amap.com/v5/direction/driving?origin={0}&destination={1}&key={2}".format(coord1,coord2,self._key))
        if r.status_code == 200:
            try:
                distance = r.json()["route"]["paths"][0]["distance"]
                return int(distance)
            except:
                return 0

if __name__=='__main__':
    addr1 = "深圳市光明区凤凰城地铁站"
    addr2 = "深圳市光明区东坑社区公园"
    wifi.connect("Kittenbot","kittenbot428")
    a = Amap()
    a._key = "9ed0e3581d6a96895befa6605e92cad4"
    a.distanceCalculation(a.searchLocation(addr1),a.searchLocation(addr2))
    