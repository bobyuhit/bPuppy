from future import *
import time

# SCD4X I2C address
SCD4X_I2C_ADDR = 0x62

# SCD4X serial number 0
SCD4X_SERIAL_NUMBER_WORD0 = 0xbe02
# SCD4X serial number 1
SCD4X_SERIAL_NUMBER_WORD1 = 0x7f07
# SCD4X serial number 2
SCD4X_SERIAL_NUMBER_WORD2 = 0x3bfb

SCD4X_CRC8_INIT = 0xFF
SCD4X_CRC8_POLYNOMIAL = 0x31

''' SCD4X Basic Commands '''
# start periodic measurement, signal update interval is 5 seconds.
SCD4X_START_PERIODIC_MEASURE = 0x21b1
# read measurement
SCD4X_READ_MEASUREMENT = 0xec05
# stop periodic measurement command
SCD4X_STOP_PERIODIC_MEASURE = 0x3f86

''' SCD4X On-chip output signal compensation '''
# set temperature offset
SCD4X_SET_TEMPERATURE_OFFSET = 0x241d
# get temperature offset
SCD4X_GET_TEMPERATURE_OFFSET = 0x2318
# set sensor altitude
SCD4X_SET_SENSOR_ALTITUDE = 0x2427
# get sensor altitude
SCD4X_GET_SENSOR_ALTITUDE = 0x2322
# set ambient pressure
SCD4X_SET_AMBIENT_PRESSURE = 0xe000

''' SCD4X Field calibration '''
# perform forced recalibration
SCD4X_PERFORM_FORCED_RECALIB = 0x362f
# set automatic self calibration enabled
SCD4X_SET_AUTOMATIC_CALIB = 0x2416
# get automatic self calibration enabled
SCD4X_GET_AUTOMATIC_CALIB = 0x2313

''' SCD4X Low power '''
# start low power periodic measurement, signal update interval is approximately 30 seconds.
SCD4X_START_LOW_POWER_MEASURE = 0x21ac
# get data ready status
SCD4X_GET_DATA_READY_STATUS = 0xe4b8

''' SCD4X Advanced features '''
# persist settings
SCD4X_PERSIST_SETTINGS = 0x3615
# get serial number
SCD4X_GET_SERIAL_NUMBER = 0x3682
# perform self test
SCD4X_PERFORM_SELF_TEST = 0x3639
# perform factory reset
SCD4X_PERFORM_FACTORY_RESET = 0x3632
# reinit
SCD4X_REINIT = 0x3646

''' SCD4X Low power single shot '''
# measure single shot
SCD4X_MEASURE_SINGLE_SHOT = 0x219d
# measure single shot rht only
SCD4X_MEASURE_SINGLE_SHOT_RHT_ONLY = 0x2196
# put the sensor from idle to sleep to reduce current consumption.
SCD4X_POWER_DOWN = 0x36e0
# wake up the sensor from sleep mode into idle mode.
SCD4X_WAKE_UP = 0x36f6

__version__ = "1.0.1"

class Sugarco2:

    def __init__(self, i2c_addr=SCD4X_I2C_ADDR):
        self._addr = i2c_addr
        self._i2c = i2c
        self.CO2ppm, self.temp, self.humidity = 0,0,0
        self.setup()

    @property
    def begin(self):
        self.enable_period_measure(SCD4X_STOP_PERIODIC_MEASURE)
        ret = True
        return ret

    def set_sleep_mode(self, mode):
        self._write_data(mode, [])
        if (SCD4X_WAKE_UP == mode):
            time.sleep(0.02)

    @property
    def perform_self_test(self):
        self._write_data(SCD4X_PERFORM_SELF_TEST, [])
        time.sleep(10)
        buf = self._read_data(3)
        return (buf[0] << 8) | buf[1]

    @property
    def module_reinit(self):
        self._write_data(SCD4X_REINIT, [])
        time.sleep(0.02)

    @property
    def perform_factory_reset(self):
        self._write_data(SCD4X_PERFORM_FACTORY_RESET, [])
        time.sleep(1.2)

    ''''''''''''''''''''''''''' Measurement Function '''''''''''''''''''''''''''

    def measure_single_shot(self, mode):
        self._write_data(mode, [])
        if (SCD4X_MEASURE_SINGLE_SHOT == mode):
            time.sleep(5)
        elif (SCD4X_MEASURE_SINGLE_SHOT_RHT_ONLY == mode):
            time.sleep(0.05)

    def enable_period_measure(self, mode):
        self._write_data(mode, [])
        if (SCD4X_STOP_PERIODIC_MEASURE == mode):
            time.sleep(0.5)

    @property
    def read_measurement(self):
        if self.get_data_ready_status:
            self._write_data(SCD4X_READ_MEASUREMENT, [])
            buf = self._read_data(9)
            CO2ppm = (buf[0] << 8) | buf[1]

            temp = -45 + 175 * (float)((buf[3] << 8) | buf[4]) / (1 << 16)

            humidity = 100 * (float)((buf[6] << 8) | buf[7]) / (1 << 16)
            self.CO2ppm, self.temp, self.humidity = CO2ppm, temp, humidity
        return self.CO2ppm, self.temp, self.humidity

    @property
    def get_data_ready_status(self):
        self._write_data(SCD4X_GET_DATA_READY_STATUS, [])
        buf = self._read_data(3)
        if (0x0000 == (((buf[0] << 8) | buf[1]) & 0x7FF)):
            return False
        return True

    def set_temp_comp(self, temp_comp):
        data = (int)(temp_comp * (1 << 16) / 175)
        send_pack = self._pack(data)
        self._write_data(SCD4X_SET_TEMPERATURE_OFFSET, send_pack)

    @property
    def get_temp_comp(self):

        self._write_data(SCD4X_GET_TEMPERATURE_OFFSET, [])
        buf = self._read_data(3)
        if (buf[2] != self._calc_CRC((buf[0] << 8) | buf[1])):
            print("The crc failed!")
        return 175 * (float)((buf[0] << 8) | buf[1]) / (1 << 16)

    def set_sensor_altitude(self, altitude):

        send_pack = self._pack(altitude)
        self._write_data(SCD4X_SET_SENSOR_ALTITUDE, send_pack)

    @property
    def get_sensor_altitude(self):

        self._write_data(SCD4X_GET_SENSOR_ALTITUDE, [])
        buf = self._read_data(3)
        return (buf[0] << 8) | buf[1]

    def set_ambient_pressure(self, ambient_pressure):

        data = (int)(ambient_pressure / 100)
        send_pack = self._pack(data)
        self._write_data(SCD4X_SET_AMBIENT_PRESSURE, send_pack)

    def perform_forced_recalibration(self, CO2ppm):

        send_pack = self._pack(CO2ppm)
        self._write_data(SCD4X_PERFORM_FORCED_RECALIB, send_pack)
        time.sleep(0.4)
        buf = self._read_data(3)
        return (int)(((buf[0] << 8) | buf[1]) - 0x8000)

    def set_auto_calib_mode(self, mode):

        data = 0
        if mode:
            data = 1
        send_pack = self._pack(data)
        self._write_data(SCD4X_SET_AUTOMATIC_CALIB, send_pack)

    @property
    def get_auto_calib_mode(self):

        self._write_data(SCD4X_GET_AUTOMATIC_CALIB, [])
        buf = self._read_data(3)
        if (0x0000 == (buf[0] << 8) | buf[1]):
            return False
        return True

    @property
    def persist_settings(self):

        self._write_data(SCD4X_PERSIST_SETTINGS, [])
        time.sleep(0.8)

    @property
    def _get_serial_number(self):

        self._write_data(SCD4X_GET_SERIAL_NUMBER, [])
        buf = self._read_data(9)
        data = [0] * 3
        data[0] = (buf[0] << 8) | buf[1]
        data[1] = (buf[3] << 8) | buf[4]
        data[2] = (buf[6] << 8) | buf[7]
        return data

    def _calc_CRC(self, data):
        crc = SCD4X_CRC8_INIT
        buf = [((data >> 8) & 0xFF), (data & 0xFF)]
        for current_byte in range(0, 2):
            crc ^= (buf[current_byte])
            for crc_bit in range(0, 8):
                if (crc & 0x80):
                    crc = (crc << 1) ^ SCD4X_CRC8_POLYNOMIAL
                else:
                    crc = (crc << 1)
        return crc & 0xFF

    def _pack(self, data):
        buf = [0] * 3
        buf[0] = ((data >> 8) & 0xFF)
        buf[1] = (data & 0xFF)
        buf[2] = self._calc_CRC(data)
        return buf

    def _write_data(self, cmd, data):
        if isinstance(data, int):
            data = [data]
        data.insert(0, (cmd & 0xFF))
        self._i2c.writeto_mem(self._addr, (cmd >> 8) & 0xFF, bytearray(data))

    def _read_data(self, length):
        return self._i2c.readfrom_mem(self._addr, 0x00, length)


    def setup(self):
        while (not self.begin):
            print('Please check that the device is properly connected')
            time.sleep(3)
        print("sensor begin successfully!!!")
        self.enable_period_measure(SCD4X_STOP_PERIODIC_MEASURE)
        self.set_temp_comp(4.0)
        print("The current temperature compensation value : %0.2f C" %
            (self.get_temp_comp))
        self.set_sensor_altitude(540)
        print("Set the current environment altitude : %u m" %
            (self.get_sensor_altitude))
        self.enable_period_measure(SCD4X_START_PERIODIC_MEASURE)
        print()

if __name__ == "__main__":
    sensor = Sugarco2(i2c_addr=SCD4X_I2C_ADDR)
    while True:
        CO2ppm, temp, humidity = sensor.read_measurement
        print("Carbon dioxide concentration : %u ppm" % CO2ppm)
        print("Environment temperature : %0.2f C" % temp)
        print("Relative humidity : %0.2f RH\n" % humidity)

        time.sleep(1)