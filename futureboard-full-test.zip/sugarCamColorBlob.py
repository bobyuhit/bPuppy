from machine import UART
from future import *
import time

__version__ = "1.0.1"

VERSIONS = 'K0'

class SugarCamColorBlob:
    def __init__(self,tx,rx):
        self.uart = UART(1,115200,tx=PINMAP[tx],rx=PINMAP[rx])
        self.updateTime = time.ticks_ms()
        self.xywh = [-1,-1,-1,-1]
        self.ipAddress = "0.0.0.0"

        self.uart.write(bytes('\n\n','utf-8'))
        time.sleep(0.4)
        flag = ''
        count = 0
        while True:
            if count == 10:
                print("Please try to reset the sugar_cam!!")
                count = 0
            data = self.uart.readline()
            print(data)
            if data:
                try:
                    flag = str(data,'UTF-8')
                    if VERSIONS in flag:
                        pass
                        break
                    else:
                        pass
                except:
                    pass
                    flag = ''
            else:
                self.uart.write('{} \r\n'.format(VERSIONS).encode())
                count+=1
                time.sleep(1)
    
    def valReset(self):
        self.xywh = [-1,-1,-1,-1]
    
    def getIpAddress(self,limit = 5000):
        startTime = time.ticks_ms()
        while True:
            if time.ticks_ms() - startTime > limit:
                return "0.0.0.0"
            self.uart.write("K2\r\n")
            self.read_from_uart()
            if self.ipAddress != "0.0.0.0":
                return self.ipAddress
            time.sleep(0.2)
    
    def read_from_uart(self):
        try:
            if time.ticks_ms() - self.updateTime > 1000:
                self.valReset()
            if self.uart.any():
                self.updateTime = time.ticks_ms()
                cmd = self.uart.read().decode().split("\r\n")[-2]
                if cmd[0] == 'K':
                    try:
                        cmd = cmd.strip().split(" ")
                    except:
                        pass
                    if cmd[0] == "K3":#feature extraction
                        self.xywh[0] = int(cmd[1])
                        self.xywh[1] = int(cmd[2])
                        self.xywh[2] = int(cmd[3]) - int(cmd[1])
                        self.xywh[3] = int(cmd[4]) - int(cmd[2])
                    elif cmd[0] == "K2":
                        self.ipAddress = cmd[1]

        except Exception as e:
            print(e)


    def setDetectionColor(self,id):
        self.uart.write("K1 %d\r\n"%(id))
        time.sleep(0.5)

