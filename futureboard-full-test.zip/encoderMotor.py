from machine import UART, Pin
from future import *
import struct
import time

__version__ = "1.2.7"


def calculate_checksum(bytes_list):

    # 初始化校验值
    cks1 = 0xAB
    cks2 = 0xAC

    # 计算累加校验
    for b in bytes_list:
        cks1 = (cks1 + b) & 0xFF
        cks2 = (cks2 + cks1) & 0xFF

    # 计算最终校验值
    checksum = (cks1 + cks2) & 0xFF
    data = bytes_list + bytearray([checksum])
    # for i in data:
    #     print(hex(i),end=",")
    # print()
    return data


def verify_checksum(data):
    if len(data) < 1:
        raise ValueError("数据不能为空")

    # 提取原始数据（去掉最后一位校验码）
    bytes_list = data[:-1]
    received_checksum = data[-1]

    # 重新计算校验码
    cks1 = 0xAB
    cks2 = 0xAC

    for b in bytes_list:
        cks1 = (cks1 + b) & 0xFF
        cks2 = (cks2 + cks1) & 0xFF

    calculated_checksum = (cks1 + cks2) & 0xFF

    # 比较校验码
    return calculated_checksum == received_checksum

class EncoderMotor:
    """编码电机控制类"""
    
    def __init__(self, tx='P0', rx='P2', id=1):
        """
        初始化编码电机
        :param tx: 发送引脚
        :param rx: 接收引脚
        :param uart_id: UART ID
        """
        self.tx = PINMAP[tx]
        self.rx = Pin(PINMAP[rx], Pin.IN, Pin.PULL_UP)
        self.uart = UART(id, 115200, tx=self.tx, rx=-1)

    def send_command(self, command):
        """发送命令到编码电机"""
        self.uart.init(tx=self.tx, rx=-1)
        self.uart.write(calculate_checksum(command))
        self.uart.init(tx=-1, rx=self.tx)

    def read_data(self, format, expectedCmd):
        """读取编码电机返回的数据"""
        try:
            data1 = self.uart.read()
            #print("readData:", data1)
            if data1:
                data1 = list(data1)
                if 0xac in data1:
                    index = data1.index(0xac)
                    data2 = data1[index:]
                    dataLen = data2[2]
                    data3 = data2[0:dataLen]
                    if verify_checksum(data3):
                        cmd = data3[3]

                        if cmd != expectedCmd:
                            return None

                        # 快速查询的指令，没有返回值，校验通过了就行
                        if cmd == 0x02:
                            return True
                        value = struct.unpack(
                            format, bytearray(data3[4:-1]))[0]
                        if value > (255 << 24):
                            return 0

                        return value
                    else:
                        return None
                else:
                    return None
            else:
                return None
        except:
            return None

    def quick_query(self, motor_id=0x01, retry=50):
        """快速查询编码电机状态"""
        self.uart.read()
        cmd = 0x02
        for i in range(retry):
            self.send_command(bytearray([0xAB, motor_id, 0x05, cmd]))
            time.sleep(0.02)
            data = self.read_data(None, cmd)
            if data:
                return data
        return False

    def save_settings(self):
        """保存编码电机设置"""
        self.send_command(bytearray([0XAB,0XFE,0X09,0X2E,0XF1,0XF2,0XF3,0XF4]))

    def change_id(self, motor_id):
        """修改编码电机ID"""
        self.send_command(bytearray([0xAB, 0xFD, 0x07, 0x10, motor_id, 0x00]))
        time.sleep_ms(10)
        self.save_settings()

    def set_mode(self, mode):
        """设置编码电机模式"""
        self.send_command(bytearray([0xAB, 0xFD, 0x07, 0x47, mode, 0x00]))

    def get_enabled_state(self, motor_id=0xFE):
        """读取电机当前使能状态（0x40寄存器）"""
        self.uart.read()
        cmd = 0x40
        self.send_command(bytearray([0xAB, motor_id, 0x05, cmd]))
        time.sleep(0.02)
        state = self.read_data("B", cmd)  # "B"为uint8
        return state

    def enable(self, motor_id=0xFE):
        """使能电机（写0x03）"""
        self.send_command(bytearray([0xAB, motor_id, 0x06, 0x40, 0x03]))

    def _auto_enable(self, motor_id=0xFE):
        """如未使能则自动使能"""
        state = self.get_enabled_state(motor_id)
        if state != 3:  # 只有不是0x03时才重新使能
            self.enable(motor_id)

    def set_speed(self, motor_id, speed, delay):
        speed = max(-700, min(700, speed))
        self._auto_enable(motor_id)
        # 使用0x4A寄存器，需要int32数据类型
        # 数据长度变为13字节：0xAB + motor_id + 0x0D + 0x4A + 4字节speed + 4字节delay
        self.send_command(bytearray([0xAB, motor_id, 0x0D, 0x4A] + 
            list(struct.pack("i", speed)) + list(struct.pack("i", delay))))

    def set_position_speed(self, motor_id, position, speed=0):
        self._auto_enable(motor_id)
        position *= 10
        self.send_command(bytearray([0xAB, motor_id, 0x0d, 0x44] + list(
            struct.pack("I", position)) + list(struct.pack("I", speed))))

    def set_position_delay(self, motor_id, position, delay=0):
        self._auto_enable(motor_id)
        position *= 10
        self.send_command(bytearray([0xAB, motor_id, 0x0d, 0x43] + list(
            struct.pack("I", position)) + list(struct.pack("I", delay))))

    def stop(self):
        self._auto_enable()
        self.send_command(bytearray([0xAB, 0xFE, 0x06, 0x40, 0x01]))
        time.sleep_ms(10)
        self.send_command(bytearray([0xAB, 0xFE, 0x06, 0x40, 0x02]))

    def get_position(self, motor_id, retry=50):
        """
        获取编码电机当前位置
        :param motor_id: 编码电机ID
        :param retry: 重试次数
        :return: 当前位置（度）
        """
        self.uart.read()
        cmd = 0x56
        for i in range(retry):
            self.send_command(bytearray([0xAB, motor_id, 0x05, cmd]))
            time.sleep(0.02)
            data = self.read_data("i", cmd)
            if data is not None:
                return data / 10
        return None

    def release(self, motor_id=0xFE, torque_mode=0x00):
        """扭矩开关状态，0x00无阻尼无扭矩，0x01有阻尼关扭矩，0x02扭矩预开启，0x03打开扭矩并在当前位置锁舵"""
        self.send_command(bytearray([0xAB, motor_id, 0x06, 0x40, torque_mode]))

    def get_max_speed(self, motor_id=0xFE, retry=50):
        """获取编码电机最大转速度（0x16寄存器）"""
        self.uart.read()
        cmd = 0x16
        for i in range(retry):
            self.send_command(bytearray([0xAB, motor_id, 0x05, cmd]))
            time.sleep(0.02)
            data = self.read_data("H", cmd)  # "H"为uint16
            if data is not None:
                return data
        return None

    def reset_angle_when_released(self, motor_id=0xFE, angle=0):
        """关闭扭矩（释放）状态下，将当前角度重置为设定值（0x51寄存器）
        :param motor_id: 电机ID
        :param angle: 目标角度（度）
        """
        # 1. 释放电机
        self.release(motor_id)
        time.sleep(0.05)
        # 2. 发送0x51命令，数据为int16，单位0.1度
        angle_val = int(angle * 10)
        angle_bytes = list(struct.pack('h', angle_val))  # int16, little-endian
        self.send_command(bytearray([0xAB, motor_id, 0x07, 0x51] + angle_bytes))
        print("="*80)
        for i in self.uart.read():
            print(hex(i),end=",")
        print()
        
        # 可选：如需恢复使能，可取消下行注释
        # self.enable(motor_id)

    def get_software_version(self, motor_id=0xFE, retry=10):
        """查询编码电机的软件版本"""
        self.uart.read()
        cmd = 0x04
        for i in range(retry):
            self.send_command(bytearray([0xAB, motor_id, 0x05, cmd]))
            time.sleep(0.02)
            data = self.read_data("I", cmd)  # "I"为uint32
            if data is not None:
                return data
        return None

    def get_hardware_version(self, motor_id=0xFE, retry=10):
        """查询编码电机的硬件版本"""
        self.uart.read()
        cmd = 0x05
        for i in range(retry):
            self.send_command(bytearray([0xAB, motor_id, 0x05, cmd]))
            time.sleep(0.02)
            data = self.read_data("I", cmd)  # "I"为uint32
            if data is not None:
                return data
        return None