from machine import UART
import sys
from future import PINMAP
__version__ = "1.0.2"


def ddmm_to_dddd(gps_ddmm):
    # 先提取度（DD）和分（MM.mmmm）部分
    degrees = int(gps_ddmm) // 100  # 取度数部分 (DD)
    minutes = float(gps_ddmm) - degrees * 100  # 取分数部分 (MM.mmmm)
    
    # 将分数部分转化为小数形式
    decimal_degrees = degrees + minutes / 60  # 分数除以60加到度数上
    
    return decimal_degrees

class SugarGPS:
    def __init__(self,tx='P2',rx='P12',id=1):
        self.uart = UART(id,9600,tx=PINMAP[tx],rx=PINMAP[rx])
        self.uart.write("$PCAS01,5*19\r\n")
        self.uart.init(baudrate = 115200)
        self.uart.write("$PCAS03,1,0,0,0,0,1,0,0,0,0,0,0,0*1E\r\n".encode())
        self.dataGGA = [-1]*15
        self.dataVTG = [-1]*10

    
    def update(self):
        try:
            data = self.uart.readline()
            if data:
                start = data.find(b'$') + 1
                end = data.find(b'*')
                substring = data[start:end]
                result = 0
                for byte in substring:
                    result ^= byte
                hex_result = hex(result)[2:].upper()
                checksum = data[end+1:end+3].decode()
                if hex_result == checksum:
                    data = data.decode().split(",")
                    if data[0] == "$GNGGA":
                        self.dataGGA = data
                    elif data[0] == "$GNVTG":
                        self.dataVTG = data
                    else:
                        print("The data type is incorrect")
                        return False
                    return True
            return False
        except KeyboardInterrupt:
            sys.exit()
        except Exception as e:
            print(e)
            return False
    
    def getTime(self,HMS):
        try:
            data = self.dataGGA[1]
            if HMS == 0:
                h = int(data[0:2])+8
                h = h if h < 24 else 24 -h
                return h
            elif HMS == 1:
                return int(data[2:4])
            elif HMS == 2:
                return int(data[4:6])
        except KeyboardInterrupt:
            sys.exit()
        except:
            return -1

    def getDataGGA(self,index):
        if not self.dataGGA[index]:
            return -1
        elif index == 2 or index == 4:
            if self.dataGGA[index] == -1:
              return -1
            x = ddmm_to_dddd(float(self.dataGGA[index]))
            return x
        elif index == 3:
            return self.dataGGA[index]
        return float(self.dataGGA[index])
    
    def getDataVTG(self,index):
        if not self.dataVTG[index]:
            return -1.0
        return float(self.dataVTG[index])