from machine import UART
from future import PINMAP
import struct
import time

__version__ = "1.0.0"

class EncMotor:
    # Frame types
    FRAME_QUERY = 0xA0
    FRAME_CTRL = 0xA1 
    FRAME_REPLY = 0xA2

    # Control commands
    CTRL_SET_ANGLE = 0xB0
    CTRL_SET_SPEED = 0xB1
    CTRL_SET_ACC = 0xB2
    CTRL_SET_PID = 0xB3
    CTRL_RESET = 0xB4
    CTRL_STOP = 0xB6
    CTRL_CALIBRATE = 0xBB
    CTRL_SETID = 0xBC

    # Query commands  
    QUERY_STATUS = 0xC0
    QUERY_DETAIL = 0xC1
    QUERY_PING = 0xC3

    def __init__(self, id=1):
        """Initialize encoder motor communication"""
        self.uart = UART(id, 1000000, tx=25, rx=39)
        time.sleep(0.1)

    def _calculate_checksum(self, data):
        """Calculate checksum for the data"""
        return sum(data) & 0xFF

    def _send_frame(self, frame_type, cmd, servo_id, data=None):
        """Send a frame to the motor"""
        if data is None:
            data = []
        
        # Construct frame
        frame = [0xFF, 0xFF, 0x00]  # Start bytes and checksum placeholder
        frame_content = [frame_type, cmd, servo_id, len(data)]
        frame_content.extend(data)
        
        # Calculate and insert checksum
        frame[2] = self._calculate_checksum(frame_content)
        frame.extend(frame_content)
        
        # Send frame
        self.uart.write(bytes(frame))

    def _read_frame(self):
        """Read and parse a response frame"""
        # Wait for start bytes
        while True:
            if self.uart.any():
                if self.uart.read(1) == b'\xff' and self.uart.read(1) == b'\xff':
                    break

        # Read frame header
        checksum = ord(self.uart.read(1))
        frame_type = ord(self.uart.read(1))
        cmd = ord(self.uart.read(1))
        servo_id = ord(self.uart.read(1))
        length = ord(self.uart.read(1))
        
        # Read data
        data = self.uart.read(length)
        
        return frame_type, cmd, servo_id, data

    def set_position(self, servo_id, position, move_time=0):
        """Set motor position with optional move time"""
        data = []
        data.extend(list(struct.pack('<f', float(position))))
        data.extend(list(struct.pack('<I', int(move_time))))
        self._send_frame(self.FRAME_CTRL, self.CTRL_SET_ANGLE, servo_id, data)

    def set_speed(self, servo_id, speed, move_time=0):
        """Set motor speed with optional move time"""
        data = []
        data.extend(list(struct.pack('<f', float(speed))))
        data.extend(list(struct.pack('<I', int(move_time))))
        self._send_frame(self.FRAME_CTRL, self.CTRL_SET_SPEED, servo_id, data)

    def stop(self, servo_id):
        """Stop motor"""
        self._send_frame(self.FRAME_CTRL, self.CTRL_STOP, servo_id)

    def set_pid(self, servo_id, kp, ki, kd):
        """Set PID parameters"""
        data = []
        data.extend(list(struct.pack('<f', float(kp))))
        data.extend(list(struct.pack('<f', float(ki))))
        data.extend(list(struct.pack('<f', float(kd))))
        self._send_frame(self.FRAME_CTRL, self.CTRL_SET_PID, servo_id, data)

    def calibrate(self, servo_id):
        """Calibrate motor encoder"""
        self._send_frame(self.FRAME_CTRL, self.CTRL_CALIBRATE, servo_id)
        time.sleep(2)  # Wait for calibration

    def get_status(self, servo_id):
        """Query motor status"""
        self._send_frame(self.FRAME_QUERY, self.QUERY_STATUS, servo_id)
        frame_type, cmd, rid, data = self._read_frame()
        
        if frame_type == self.FRAME_REPLY and cmd == self.QUERY_STATUS and len(data) >= 16:
            current_angle, target_angle, current_speed, output = struct.unpack('<ffff', data[:16])
            return {
                'current_angle': current_angle,
                'target_angle': target_angle,
                'current_speed': current_speed,
                'output': output
            }
        return None 

    def query_ping(self, servo_id=0, timeout=1000):
        """Query motor ping, returns a list of all responses within timeout
        Args:
            servo_id: 0 for broadcast, or specific motor ID
            timeout: max wait time in seconds
        Returns:
            List of dictionaries containing responses from all motors
        """
        responses = []
        self._send_frame(self.FRAME_QUERY, self.QUERY_PING, servo_id)
        
        # Wait for responses with timeout
        start_time = time.ticks_ms()
        while (time.ticks_ms() - start_time) < timeout:
            if self.uart.any():
                try:
                    frame_type, cmd, rid, data = self._read_frame()
                    if frame_type == self.FRAME_REPLY and cmd == self.QUERY_PING:
                        model, firmware_ver, dev_id = struct.unpack('<HHB', data)
                        responses.append({
                            'model': model,
                            'firmware_ver': firmware_ver, 
                            'id': dev_id
                        })
                except:
                    pass
            # Small delay to prevent busy waiting
            time.sleep_ms(10)
        
        return responses