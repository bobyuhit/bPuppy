import struct

__VERSION__ = "0.1.3"
class EncServo:
    def __init__(self, i2c, addr) -> None:
        self.address = addr
        self.i2c = i2c
        # self.set_position_pid_parameters(0.02, 0.08, 0.005)
        # self.set_velocity_pid_parameters(0.1, 0.0, 0.0)
        

    def set_max_out(self, max_out):
        buf = struct.pack('f', max_out)
        self.i2c.writeto(self.address, b'\x07' + buf)

    # Set motor target
    # Command structure: 0x05 + float (target_position) + float (time_sec)
    def set_motor_target(self, target_position, time_sec):
        buf = struct.pack('ff', target_position, time_sec)
        self.i2c.writeto(self.address, b'\x05' + buf)

    def set_motor_speed(self, speed, delay):
        speed*=100
        buf = struct.pack('hh', speed, delay)
        self.i2c.writeto(self.address, b'\x02' + buf)

    # Set motor position
    # Command structure: 0x06 + float (position)
    def set_motor_position(self, position):
        buf = struct.pack('f', position)
        self.i2c.writeto(self.address, b'\x06' + buf)

    # Set position PID parameters
    # Command structure: 0x03 + 3 float values (kp, ki, kd)
    def set_position_pid_parameters(self, kp, ki, kd):
        buf = struct.pack('fff', kp, ki, kd)
        self.i2c.writeto(self.address, b'\x03' + buf)

    # Set velocity PID parameters
    # Command structure: 0x04 + 3 float values (kp, ki, kd)
    def set_velocity_pid_parameters(self, kp, ki, kd):
        buf = struct.pack('fff', kp, ki, kd)
        self.i2c.writeto(self.address, b'\x04' + buf)
        
    # set zero position
    def set_zero_position(self):
        self.i2c.writeto(0x1C, b'\x09')
        
    # move relative
    def move_relative(self, distance, time_sec=0):
        buf = struct.pack('ff', distance, time_sec)
        self.i2c.writeto(0x1C, b'\x0A' + buf)
        
    def read_motor_status(self):
        self.i2c.writeto(self.address, b'\x08')
        buf = self.i2c.readfrom(self.address, 13)
        pos, relative, vel, status = struct.unpack('fffB', buf)
        return pos, relative, vel, status
