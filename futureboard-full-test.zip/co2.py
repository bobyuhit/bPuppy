import time
from future import i2c

__version__ = "1.0.0"

# I2C address of the device
SGP30_DEFAULT_ADDRESS = 0x58

# SGP30 Register Set
SGP30_INIT = 0x2003
SGP30_MEASURE_IAQ = 0x2008

class SGP30:
    def __init__(self):
        self.bus = i2c
        self.co2eq = 0
        self.tvoc = 0
        self.init_sgp30()
    
    def init_sgp30(self):
        # Initialize SGP30
        self.bus.writeto_mem(SGP30_DEFAULT_ADDRESS, SGP30_INIT >> 8, bytearray([SGP30_INIT & 0xFF]))
        time.sleep(1)
    
    def read_air_quality(self):
        # Start air quality measurement
        self.bus.writeto_mem(SGP30_DEFAULT_ADDRESS, SGP30_MEASURE_IAQ >> 8, bytearray([SGP30_MEASURE_IAQ & 0xFF]))
        time.sleep(0.01)
        
        # Read air quality data from SGP30
        data = self.bus.readfrom_mem(SGP30_DEFAULT_ADDRESS, 0, 6)
        
        # Convert the data
        self.co2eq = (data[0] << 8) | data[1]
        self.tvoc = (data[3] << 8) | data[4]
        return self.co2eq,self.tvoc
		

if __name__ == '__main__':
    sgp30 = SGP30()

    while True:
        sgp30.read_air_quality()
        print("CO2eq: {}, TVOC: {}".format(sgp30.co2eq, sgp30.tvoc))
        time.sleep(1)
